package com.zerokorez.general;

import android.view.MotionEvent;

public interface Interactive {
    boolean receiveTouch(MotionEvent event);
}
