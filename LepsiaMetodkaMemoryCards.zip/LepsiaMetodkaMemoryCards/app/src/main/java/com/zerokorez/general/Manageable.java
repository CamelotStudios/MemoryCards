package com.zerokorez.general;

public interface Manageable {
    void setState(boolean state);
    boolean getState();
}
